import React from "react";
import Signup from "./signup/page";

function App() {
  return (
    <div className="App">
      <Signup />
    </div>
  );
}

export default App;
