import { useState } from "react";

export default function Header(props: any) {
  return (
    <div className="box col">
      {/* logo */}
      <div className="box center-item row space">
        <div className="box row center-item">
          <svg
            width="24px"
            height="24px"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              opacity="0.4"
              fillRule="evenodd"
              clipRule="evenodd"
              d="M7.42233 19.8203C7.84433 19.8203 8.18733 20.1633 8.18733 20.5853C8.18733 21.0073 7.84433 21.3493 7.42233 21.3493C7.00033 21.3493 6.65833 21.0073 6.65833 20.5853C6.65833 20.1633 7.00033 19.8203 7.42233 19.8203Z"
              stroke="#FF6C18"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              opacity="0.4"
              fillRule="evenodd"
              clipRule="evenodd"
              d="M18.6747 19.8203C19.0967 19.8203 19.4397 20.1633 19.4397 20.5853C19.4397 21.0073 19.0967 21.3493 18.6747 21.3493C18.2527 21.3493 17.9097 21.0073 17.9097 20.5853C17.9097 20.1633 18.2527 19.8203 18.6747 19.8203Z"
              stroke="#FF6C18"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M2.74988 3.25L4.82988 3.61L5.79288 15.083C5.87088 16.018 6.65188 16.736 7.58988 16.736H18.5019C19.3979 16.736 20.1579 16.078 20.2869 15.19L21.2359 8.632C21.3529 7.823 20.7259 7.099 19.9089 7.099H5.16388"
              stroke="#FF6C18"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              opacity="0.4"
              d="M14.1254 10.7949H16.8984"
              stroke="#FF6C18"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <h1 className="textUi f-18" style={{ fontWeight: "400" }}>
            MyShopy
          </h1>
        </div>
        {props.staps !== 33 ? (
          <div className="box center-item row space" onClick={props.Back}>
            <svg
              version="1.1"
              style={{ width: "12px" }}
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 477.175 477.175"
            >
              <path
                d="M145.188,238.575l215.5-215.5c5.3-5.3,5.3-13.8,0-19.1s-13.8-5.3-19.1,0l-225.1,225.1c-5.3,5.3-5.3,13.8,0,19.1l225.1,225
		c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4c5.3-5.3,5.3-13.8,0-19.1L145.188,238.575z"
              />
            </svg>
            <span>Back</span>
          </div>
        ) : (
          ""
        )}
      </div>
      <div className="box center-item row space">
        <b className="f-18 pt-18" style={{ padding: "18px 0 8px 0" }}>
          Create account
        </b>
        <div
          className="timeline"
          style={{
            width: "130px",
            borderRadius: "10px",
            border: "1px solid #ddd",
            height: "5px",
            marginRight: "50px",
          }}
        >
          <div
            style={{
              width: props.staps + "%",
              borderRadius: "10px",
              backgroundColor: "#ff6c18",
              height: "5px",
            }}
          ></div>
        </div>
      </div>
    </div>
  );
}
export function FormPaymonet(props: any) {
  let [rotate, setRot] = useState("rotate(270deg)");
  let [isOpen, setIsOpen] = useState(false);
  let [data, setData] = useState("Enter card type");
  function Open() {
    if (isOpen) {
      setRot("rotate(0deg)");
      setIsOpen(false);
    } else {
      setRot("rotate(270deg)");
      setIsOpen(true);
    }
  }
  function setList(e: any) {
    setData(e.target.textContent);
    Open();
  }

  function Next(e: any) {
    e?.preventDefault();
    let list = ["Master Card", "Visa", "Payoneer"];
    let filter: string[] = list.filter((a) => a === data);

    if (filter.length === 1) {
      console.log(filter.length);
      props.Next();
    }

    // props.Next();
  }
  return (
    <form
      onSubmit={Next}
      className={`paymonet ${props.staps === 99 ? "" : "none"}`}
    >
      <div className={``}>
        <p className="textUi">Card type</p>
        <div className="box row space input-list" onClick={Open}>
          <div>{data}</div>
          <svg
            version="1.1"
            style={{ width: "12px", transform: rotate }}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 477.175 477.175"
          >
            <path
              d="M145.188,238.575l215.5-215.5c5.3-5.3,5.3-13.8,0-19.1s-13.8-5.3-19.1,0l-225.1,225.1c-5.3,5.3-5.3,13.8,0,19.1l225.1,225
		c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4c5.3-5.3,5.3-13.8,0-19.1L145.188,238.575z"
            />
          </svg>
        </div>
        <ul className={`box col list ${isOpen ? "" : "none"}`}>
          <li onClick={setList}>Master Card</li>
          <li onClick={setList}>Visa</li>
          <li onClick={setList}>Payoneer</li>
        </ul>
        {/* img card  */}
        <img
          src="/visa.png"
          alt=""
          width={260}
          height={100}
          className="bor img-cardPay"
        />
      </div>
      <div className=" boxSend">
        <p>Sign in instead</p>
        {/* send */}
        <button type={"submit"}>Signup</button>
      </div>
    </form>
  );
}
export function query(q: string) {
  return document.querySelector(`input[name="${q}"]`) as HTMLInputElement;
}
export function Dane(props: any) {
  let name: string = query("first").value;
  return (
    <div className={ ` dane ${props.staps > 100 ? "" : "none"}`}>
      <b>Welcome,{name} </b>
    </div>
  );
}
