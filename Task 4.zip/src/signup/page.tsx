import { useState } from "react";
import { FormMap } from "./formmap";
import Header, { Dane, FormPaymonet } from "./mico";
import "./page.sass";
import FormUserInfo from "./userinfo";
export default function Signup(): any {
  let [staps, setStaps] = useState(33);

  function Next(e: any) {
    e?.preventDefault();

    setStaps(staps + 33);
  }
  function Back() {
    setStaps(staps - 33);
  }

  //   let BtnContext = "Signup";

  //
  let Image;
  if (staps < 100) {
    Image = <img src={`/${staps / 33}.png`} alt="" className="bor img-info" />;
  }
  return (
    <div>
      <div className="contenar">
        {/* sign up */}
        <Header staps={staps} Back={Back} />
        <div className="boxForm box row">
          {/* content */}

          <FormUserInfo staps={staps} Next={Next} />
          <FormMap staps={staps} Next={Next} />
          <FormPaymonet staps={staps} Next={Next} />
          <Dane staps={staps} />
          {/* <div className=" boxSend">
                <p>Sign in instead</p> 
                <button onClick={Next}>{BtnContext}</button>
            </div> */}
          {Image}
          {/* image */}
        </div>
      </div>
    </div>
  );
}
